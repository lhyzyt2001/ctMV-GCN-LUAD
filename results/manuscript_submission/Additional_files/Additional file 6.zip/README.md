# Additional file 6

Title: Final reproducibility audit and sensitivity-analysis code

This archive contains the two final sensitivity analyses added after the frozen v1.0.2 computational release and a code-derived audit of reproducibility parameters.

## Contents

- `run_final_sensitivity.py`: portable executable Python script for the Cox proportional-hazards diagnostics and gene-cluster bootstrap.
- `cox_ph_schoenfeld_covariate_tests.csv`: per-covariate Schoenfeld-residual tests.
- `cox_ph_model_summary.csv`: model-level summary of nominal and FDR-adjusted diagnostic flags.
- `gene_cluster_bootstrap_replicates.csv`: all 2,000 matched gene-cluster bootstrap replicates.
- `gene_cluster_bootstrap_summary.csv`: prespecified summary contrast between ctMV-GCN and network-degree logistic regression.
- `final_sensitivity_manifest.json`: machine-readable analysis summary and runtime version.
- `reproducibility_parameter_audit.csv`: parameters extracted from the final v1.0.2 source code.

## Scope

These files do not alter the graph, labels, fitted model scores, candidate list or previously reported primary analyses. They provide diagnostic and sensitivity checks supporting the final manuscript. The archived main pipeline remains v1.0.2 at DOI `10.5281/zenodo.21870287`.

## Execution

Run under Python 3.11 from the repository root. Supply the original TCGA expression file and the two frozen GSE68465 processed caches; paths may be absolute or relative:

```text
python src/sensitivity/run_final_sensitivity.py \
  --tcga-expression <path-to-HiSeqV2> \
  --gse-metadata <path-to-GSE68465_sample_metadata.csv.gz> \
  --gse-expression <path-to-GSE68465_robust_top20_expression.csv.gz>
```

By default, the script reads the frozen v1.0.2-derived tables from `results/` and writes the new outputs to `results/sensitivity/`. Optional arguments allow the TCGA cohort table, raw graph dataset, results root and output directory to be overridden without editing source code. Run `python src/sensitivity/run_final_sensitivity.py --help` for the complete interface.
